module.exports = {

  title: '智能实验室后台管理系统',
  showSettings: true,
  tagsView: false,
  fixedHeader: true,
  sidebarLogo: true,
  errorLog: 'production'
  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  /**
   * @type {boolean} true | false
   * @description Whether show the logo in sidebar
   */
}
