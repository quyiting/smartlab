<template>
  <!-- 具备一个宽高的dom容器 -->
  <div :class="className" :id="id" :style="{ height: height, width: width }" />
</template>

<script>
// 引入
import echarts from "echarts";
// 引入主题
require("echarts/theme/macarons");

// 自适应窗口大小改变图表的大小
import resize from "./mixins/resize";

export default {
  mixins: [resize],

  props: {
    className: {
      type: String,
      default: "chart",
    },
    id: {
      type: String,
      default: "chart",
    },
    width: {
      type: String,
      default: "100%",
    },
    height: {
      type: String,
      default: "500px",
    },
  },

  data() {
    return {
      chart: null,
      option: Object,
      count: 11,
    };
  },
  created() {
    this.option = {
      title: {
        top: 0,
        text: "实验室实时温度",
        subtext: "可燃气体浓度",
        textStyle: {
          fontWeight: "normal",
          fontSize: 22,
        },
        left: "0%",
      },
      tooltip: {
        show: true,
        trigger: "axis",
        axisPointer: {
          tpye: "cross",
          label: {
            backgroundColor: "#283b56",
          },
        },
      },
      legend: {
        data: ["室内气温", "室内可燃气 "],
      },
      dataZoom: {
        show: false,
        start: 0,
        end: 100,
      },
      toolbox: {
        show: true,
        feature: {
          dataView: { readOnly: false },
          restore: {},
          saveAsImage: {},
        },
      },
      xAxis: [
        { 
          axisLabel: {
            color: "#F08080",
            fontSize:14,
            fontWeight:600
          },
          type: "category",
          boundaryGap: true,
          data: (function () {
            var now = new Date();
            var res = [];
            var len = 10;
            while (len--) {
              res.unshift(now.toLocaleTimeString().replace(/^\D*/, ""));
              now = new Date(now - 2000);
            }
            return res;
          })(),
        },
        { 
          axisLabel: {
            color: "#F08080",
            fontSize:14,
            fontWeight:600
          },
          type: "category",
          boundaryGap: true,
          data: (function () {
            var res = [];
            var len = 10;
            while (len--) {
              res.push(10 - len - 1);
            }
            return res;
          })(),
        },
      ],
      yAxis: [
        {
          nameTextStyle: {
            fontSize: 16,
            color: "#F08080",
          },
          splitLine: {
            show: false,
          },
          type: "value",
          scale: true,
          name: "室温",
          max: 50,
          min: 0,
          boundaryGap: [0.2, 0.2],
          axisLabel: {
            color: "#F08080",
            fontSize: 18,
          },
        },
        {
          nameTextStyle: {
            fontSize: 16,
            color: "#F08080",
          },
          splitLine: {
            show: false,
          },
          type: "value",
          scale: true,
          name: "可燃气浓度",
          max: 100,
          min: 0,
          boundaryGap: [0.2, 0.2],
          axisLabel: {
            color: "#F08080",
            fontSize: 18,
          },
        },
      ],
      series: [
        {
          name: "浓度",
          type: "bar",
          xAxisIndex: 1,
          yAxisIndex: 1,
          data: (function () {
            var res = [];
            var len = 10;
            while (len--) {
              res.push(Math.round(Math.random() * 10 +3));
            }
            return res;
          })(),
          itemStyle: {
            normal: {
              //柱形图圆角，顺时针左上，右上，右下，左下）
              barBorderRadius: [12, 12, 0, 0],
              //设置柱状图颜色渐变
              color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "#f75d5d",
                },
                {
                  offset: 1,
                  color: "#f0caca",
                },
              ]),
            },
          },
        },
        {
          name: "气温",
          type: "line",
          data: (function () {
            var res = [];
            var len = 0;
            while (len < 10) {
              res.push((Math.random() * 1 + 28).toFixed(1) - 0);
              len++;
            }
            return res;
          })(),
          lineStyle: {
            // 线性渐变，前四个参数分别是 x0, y0, x2, y2, 范围从 0 - 1，相当于在图形包围盒中的百分比，如果 globalCoord 为 `true`，则该四个值是绝对的像素位置
            color: {
              type: "linear",
              x: 0,
              y: 0,
              x2: 1,
              y2: 0,
              colorStops: [
                {
                  offset: 0,
                  color: "#D02090", // 0% 处的颜色
                },
                {
                  offset: 1,
                  color: "#EE82EE10", // 100% 处的颜色
                },
              ],
              globalCoord: false, // 缺省为 false
            },
            width: 2,
            shadowBlur: 10,
            shadowColor: "rgba(255,182,193,0.9)",
            shadowOffsetX: 10,
            shadowOffsetY: 20,
          },
        },
      ],
    };
  },
  mounted() {
    this.initChart();
  },

  // 当组件销毁之前会调用此钩子，
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    // 注销实例
    this.chart.dispose();
    this.chart = null;
  },

  methods: {
    initChart() {
      this.chart = echarts.init(document.getElementById(this.id));
      this.chart.setOption(this.option);
      setInterval(() => {
        var axisData = new Date().toLocaleTimeString().replace(/^\D*/, "");

        var data0 = this.option.series[0].data;
        var data1 = this.option.series[1].data;
        data0.shift();
        data0.push(Math.round(Math.random() * 10 + 5));
        data1.shift();
        data1.push((Math.random() * 1 + 28).toFixed(1) - 0);

        this.option.xAxis[0].data.shift();
        this.option.xAxis[0].data.push(axisData);
        this.option.xAxis[1].data.shift();
        this.option.xAxis[1].data.push(this.count++);

        this.chart.setOption(this.option);
      }, 2000);
      if (this.ption && typeof this.option === "object") {
        this.chart.setOption(this.option, true);
      }
    },
  },
};
</script>