<template>
  <div class="app-container">
    <!-- 条件查询 -->
    <el-form :inline="true" size="mini">
      <el-form-item label="标签名称:">
        <el-input v-model.trim="query.name"></el-input>
      </el-form-item>
      <el-form-item label="分类名称:">
        <!-- clearable 清空按钮，filterable 是否可搜索 -->
        <el-select v-model="query.categoryId" clearable filterable>
          <el-option
            v-for="item in categoryList"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button icon="el-icon-search" type="primary" @click="queryData"
          >查询</el-button
        >
        <el-button icon="el-icon-refresh" class="filter-item" @click="reload"
          >重置</el-button
        >
        <el-button
          type="primary"
          size="mini"
          icon="el-icon-circle-plus-outline"
          @click="openAdd"
          >新增</el-button
        >
      </el-form-item>
    </el-form>
    <!-- 数据列表 :data 绑定渲染的数据， border纵向边框 -->
    <el-table :data="list" border highlight-current-row style="width: 100%">
      <el-table-column align="center" type="index" label="序号" width="60">
      </el-table-column>

      <el-table-column
        align="center"
        prop="name"
        label="标签名称"
      ></el-table-column>

      <el-table-column
        align="center"
        prop="categoryName"
        label="分类名称"
      ></el-table-column>
      <el-table-column
        align="center"
        prop="categoryName1"
        label="存放位置(抽屉编号)"
      ></el-table-column>

      <el-table-column align="center" label="操作">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row.id)"
            >编辑</el-button
          >
          <el-button
            size="mini"
            type="danger"
            @click="handleDelete(scope.row.id)"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page.current"
      :page-sizes="[10, 20, 50]"
      :page-size="page.size"
      :total="page.total"
      layout="total, sizes, prev, pager, next, jumper"
    >
    </el-pagination>
    <edit
      :categoryList="categoryList"
      :title="edit.title"
      :visible="edit.visible"
      :formData="edit.formData"
      :remoteClose="remoteClose"
    >
    </edit>
  </div>
</template>
<script>
import api from "@/api/label";
import categoryApi from "@/api/category";
import Edit from "./edit";
export default {
  name: "Lable",
  components: { Edit },
  data() {
    return {
      categoryList: [],
      list: [],
      page: {
        total: 0,
        current: 1,
        size: 20,
      },
      edit: {
        title: "",
        visible: false,
        formData: {},
      },
      query: {},
    };
  },
  created() {
    this.fetchData();
    this.getCategoryList();
  },
  methods: {
    fetchData() {
      api
        .getList(this.query, this.page.current, this.page.size)
        .then((response) => {
          this.list = response.data.records;
          this.page.total = response.data.total;
        });
    },
    handleEdit(id) {
      api.getById(id).then((response) => {
        if (response.code === 20000) {
          this.edit.formData = response.data;
          this.edit.visible = true;
          this.edit.title = "编辑";
        }
      });
    },
    handleDelete(id) {
      this.$confirm("确认删除这条记录吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          api.deleteById(id).then((response) => {
            this.$message({
              type: response.code === 20000 ? "success" : "error",
              message: response.message,
            });
            this.fetchData();
          });
        })
        .catch(() => {});
    },
    handleSizeChange(val) {
      this.page.size = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.page.current = val;
      this.fetchData();
    },
    getCategoryList() {
      categoryApi.getNormalList().then((response) => {
        this.categoryList = response.data;
      });
    },
    queryData() {
      this.page.current = 1;
      this.fetchData();
    },
    reload() {
      this.query = {};
      this.fetchData();
    },
    remoteClose() {
      this.edit.formData = {};
      this.edit.visible = false;
      this.fetchData();
    },
    openAdd() {
      this.getCategoryList();
      this.edit.visible = true;
      this.edit.title = "新增";
    },
  },
};
</script>