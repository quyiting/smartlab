<template>
  <el-dialog
    :title="title"
    :visible.sync="visible"
    width="500px"
    :before-close="handleClose"
  >
    <el-form
      :rules="rules"
      status-icon
      ref="formData"
      :model="formData"
      label-position="right"
      label-width="100px"
      style="width: 400px"
    >
      <el-form-item label="名称：" prop="name">
        <el-input v-model="formData.name" />
      </el-form-item>
      <el-form-item label="所在学院：" prop="student">
        <el-input />
      </el-form-item>
      <el-form-item label="学号：" prop="number">
        <el-input />
      </el-form-item>
      
      <el-form-item label="健康码：" prop="status">
        <el-radio-group v-model="formData.status">
          <el-radio :label="1">正常</el-radio>
          <el-radio :label="0">禁用</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="排序：" prop="sort">
        <el-input-number
          style="width: 300px"
          v-model="formData.sort"
          :min="1"
          :max="10000"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm('formData')" size="mini">
          确认</el-button
        >
        <el-button size="mini" @click="handleClose">取消</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>
<script>
import api from '@/api/category'
export default {
  props: {
    title: {
      type: String,
      default: "",
    },
    visible: {
      //弹出窗口，true弹出
      type: Boolean,
      default: false,
    },
    formData: {
      type: Object,
      default: {},
    },
    remoteClose: Function, //用于关闭窗口
  },
  data() {
    return {
      rules: {
        name: [{ required: true, message: "请输入名称", trigger: "blur" }],
        status: [{ required: true, message: "请选择状态", trigger: "change" }],
        sort: [{ required: true, message: "请输入排序号", trigger: "change" }],
        student:[{ required: true, message: "请输入学院", trigger: "blur" }],
        number:[{ required: true, message: "请输入学号", trigger: "blur" }],
      },
    };
  },
  methods: {
    handleClose(done) {
      this.$refs["formData"].resetFields();
      this.remoteClose();
    },
    //提交表单
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //校验通过，提交数据
          this.submitData();
        } else {
          //验证不通过
          return false;
        }
      });
    },
    //异步方法提交数据
    async submitData() {
      let response = null;
      if(this.formData.id){
          response = await api.update(this.formData)
      }else {
          response = await api.add(this.formData)
      }
      if (response.code === 20000) {
        this.$message({
          message: "保存成功",
          type: "success",
        });
        this.handleClose();
      } else {
        this.$message({
          type: "error",
          message: "保存失败",
        });
      }
    },
  },
  submitForm(formName) {},
};
</script>