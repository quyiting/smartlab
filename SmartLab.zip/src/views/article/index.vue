<template>
  <div class="app-container">
    <audit
      :id="audit.id"
      :isAudit="audit.isAudit"
      :title="audit.title"
      :visible="audit.visible"
      :remoteClose="remoteClose"
    />
    <el-form :inline="true" size="mini">
      <el-form-item label="物品名称:">
        <el-input v-model.trim="query.title"></el-input>
      </el-form-item>
      <el-form-item label="状态:">
        <!-- clearable 清空按钮，filterable 是否可搜索 -->
        <el-select
          v-model="query.status"
          clearable
          filterable
          style="width: 100px"
        >
          <!-- :value="1" 是数字1，value="1"是字符串“1” 0: 已删除, 1:未审核，2:审核通过，3：审核未通过-->
          <el-option :value="1" label="未租借"></el-option>
          <el-option :value="2" label="已租借"></el-option>
          <el-option :value="3" label="报修中"></el-option>

        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button icon="el-icon-search" type="primary" @click="queryData"
          >查询</el-button
        >
        <el-button icon="el-icon-refresh" class="filter-item" @click="reload"
          >重置</el-button
        >
      </el-form-item>
    </el-form>
    <!-- 数据列表 :data 绑定渲染的数据, border 纵向边框 -->
    <el-table :data="list" border highlight-current-row style="width: 100%">
      <el-table-column
        align="center"
        type="index"
        label="序号"
        width="60"
      ></el-table-column>
      <el-table-column
        align="center"
        prop="title"
        label="物品名称"
      ></el-table-column>
      <el-table-column
        align="center"
        prop="viewCount"
        label="物品编号"
      ></el-table-column>
      <el-table-column
        align="center"
        prop="thumhup"
        label="物品使用者"
      ></el-table-column>
      
      <el-table-column align="center" prop="status" label="状态">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.status === 1">未租借</el-tag>
          <el-tag v-if="scope.row.status === 2" type="success">已租借</el-tag>
          <el-tag v-if="scope.row.status === 3" type="warning"
            >报修中</el-tag
          >
        </template></el-table-column
      >
      <el-table-column align="center" prop="updateDate" label="最后更新时间">
        <!-- <template slot-scope="scope">
          {{ getFormat(scope.row.updateDate) }}
        </template> -->
      </el-table-column>
      <el-table-column align="center" label="操作" width="220">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="openView(scope.row.id)"
            type="primary"
            >查看</el-button
          >
          <el-button
            size="mini"
            v-if="scope.row.status === 1"
            @click="openAudit(scope.row.id)"
            type="success"
            >审核</el-button
          >
          <el-button
            size="mini"
            v-if="scope.row.status !== 0"
            @click="handleDelete(scope.row.id)"
            type="danger"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="page.current"
      :page-sizes="[10, 20, 50]"
      :page-size="page.size"
      :total="page.total"
      layout="total, sizes, prev, pager, next, jumper"
    >
    </el-pagination>
  </div>
</template>
<script>
import api from "@/api/article";
import { format } from "@/utils/date";
import Audit from "./audit";
export default {
  components: { Audit },
  name: "Article",
  data() {
    return {
      audit: {
        id: null,
        isAudit: true,
        visible: false,
        title: "",
      },
      list: [],
      page: {
        total: 0,
        current: 1,
        size: 20,
      },
      query: {},
    };
  },
  created() {
    this.fetchData();
  },
  methods: {
    fetchData() {
      api
        .getList(this.query, this.page.current, this.page.size)
        .then((response) => {
          // console.log(response)
          this.list = response.data.records;
          this.page.total = response.data.total;
        });
    },
    getFormat(date) {
      return format(date);
    },
    openAudit(id) {
      this.audit.id = id;
      this.audit.isAudit = true;
      this.audit.title = "审核";
      this.audit.visible = true;
    },
    handleDelete(id) {
      this.$confirm("确认删除这条记录吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          api.deleteById(id).then((response) => {
            this.$message({
              type: 'success',
              message:'删除成功'
            });
            this.fetchData();
          });
        })
        .catch(() => {});
    },
    handleSizeChange(val) {
      this.page.size = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.page.current = val;
      this.fetchData();
    },
    queryData() {
      this.page.current = 1;
      this.fetchData();
    },
    reload() {
      this.query = {};
      this.fetchData();
    },
    remoteClose() {
      this.audit.visible = false;
      this.fetchData();
    },
    openView(id) {
      this.audit.id = id
      this.audit.id = id
      this.audit.isAudit = false
      this.audit.title = '文章详情'
      this.audit.visible = true
    }
  },
};
</script>