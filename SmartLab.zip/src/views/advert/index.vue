<template>
  <div>
    <div class="amap-page-container">
      <el-amap
        ref="map"
        vid="amapDemo"
        :amap-manager="amapManager"
        :center="center"
        :zoom="zoom"
        :plugin="plugin"
        :events="events"
        class="amap-demo"
      >
      </el-amap>
    </div>
  </div>
</template>
<script>
// 引入AMapManager
import { AMapManager } from "vue-amap";
//获取实例
let amapManager = new AMapManager();
export default {
  data() {
    return {
      amapManager,
      zoom: [15, 19],
      center: [120.19, 30.26],
      events: {
        init: (o) => {
          o.getCity((result) => {
            console.log(result);
          });
        },
        click: (e) => {
          console.log(e);
        },
      },
    };
  },
};
</script>
<style scoped>
.amap-page-container {
  width: 100%;
  height: 400px;
}
</style>
