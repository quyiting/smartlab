<template>
  <div>
    <div id="myChart" style="width：300px;height:300px"></div>
    
  </div>
</template>

<script>
export default {
  name: "hello",
  data() {
    return {
      data: [],
      now: new Date(),
      oneDay: 24 * 3600 * 1000,
      value: Math.random() * 100,
    };
  },
  mounted() {
    for (var i = 0; i < 1000; i++) {
      this.data.push(this.randomData());
    }
    this.drawLine();
    let that = this;
    let myChart = this.$echarts.init(document.getElementById("myChart"));
    this.timer = setInterval(function () {
      // 数据小于40的时候只添加，超过40的时候删除第一个
      // if(that.data.length<40){
      if (that.data.length < 500) {
        that.data.push(that.randomData());
      } else {
        for (var i = 0; i < 5; i++) {
          // console.log(that.data)
          that.data.shift();
          
          that.data.push(that.randomData());
        }
      }

      myChart.setOption({
        series: [
          {
            data: that.data,
          },
        ],
      });
    }, 1000);
  },
  created() {},
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    randomData() {
      this.now = new Date(+this.now + this.oneDay);
      this.value = this.value + Math.random() * 100 - 50;
      return {
        name: this.now.toString(),
        value: [
          [
            this.now.getFullYear(),
            this.now.getMonth() + 1,
            this.now.getDate(),
          ].join("/"),
          Math.round(this.value),
        ],
      };
    },
    drawLine() {
      // 基于准备好的dom，初始化echarts实例
      let myChart = this.$echarts.init(document.getElementById("myChart"));
      // 绘制图表
      myChart.setOption({
        title: {
          top: 10,
          left: 10,
          text: "空气湿度情况",
          textStyle: {
            color: "#8B3A3A",
            fontSize: 22,
          },
          subtext: "湿度准线：45%",
          subtextStyle:{
            fontSize:16,
            color:"#FF8247"
          }
        },
        tooltip: {
          trigger: "axis",
          show: false,
          formatter: function (params) {
            params = params[0];
            var date = new Date(params.name);
            return (
              date.getDate() +
              "/" +
              (date.getMonth() + 1) +
              "/" +
              date.getFullYear() +
              " : " +
              params.value[1]
            );
          },
          axisPointer: {
            animation: false,
          },
        },
        xAxis: {
          type: "time",
          splitLine: {
            show: false,
          },
          axisLabel: {
            show: false,
          },
          axisTick: {
            show: false,
          },
        },
        yAxis: {
          type: "value",
          show: false,
          boundaryGap: [0, "100%"],
          splitLine: {
            show: false,
          },
        },
        series: [
          {
            name: "模拟数据",
            type: "line",
            showSymbol: false,
            hoverAnimation: false,

            data: this.data,
          },
        ],
      });
    },
  },
};
</script>

<style scoped lang="less">
</style>