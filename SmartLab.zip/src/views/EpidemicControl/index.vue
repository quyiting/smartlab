<template>
  <div class="dashboard-editor-container">
    <div class="people_frames">
      <div class="people_frame">
        <span class="people_number">14</span>
        <span class="people_text">今日到场人数</span>
      </div>
      <div class="people_frame">
        <span class="people_number">14</span>
        <span class="people_text">体温正常人数</span>
      </div>
      <div class="people_frame">
        <span class="people_number">优</span>
        <span class="people_text">空气质量</span>
      </div>
      
      <div class="people_frame">
        <span class="people_number">45%</span>
        <span class="people_text">空气湿度</span>
      </div>
      

    </div>
    <div class="chart_frames">
      <div class="chart-wrapper">
        <line-chart style="width:100%;height:100%;margin-left:70px" />
      </div>
      
      <div class="chart-wrapper">
        <line-chart-2 style="width:100%;height:100%;" />
      </div>
  
    </div>
  </div>
</template>
<script>

import LineChart from './components/LineChart'
import LineChart2 from './components/LineChart2'

export default {
  name: 'Epidemic',
  components: {
    LineChart,
    LineChart2,



  },
  data() {
    return {
      
    }
  },
  mounted() {
    
  },
  methods: {
    
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(255, 255, 255);
  position: relative;
}
.people_frames {
  position: relative;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr ;
  height: 150px;
  width: auto;
  margin-left: 100px;
}
.people_frame {
  position: relative;
  width: 170px;
  height: 140px;
  padding:0 7px;
  background: rgb(255, 255, 255);
  display: grid;
  margin-right: 30px;
  grid-template-rows: 1fr 1fr;
  place-items: center;
  box-shadow: 0px 0px 5px rgb(0 0 0 / 16%);
}
.people_number {
  margin-top: 30px;
  font-size: 50px;
  color: rgb(131, 131, 131);
}
.people_text {
  margin-top:4px;
  font-size: 13px;
  font-weight: 300;
  color: rgb(131, 131, 131);
}
.chart_frames {
  position: relative;
  margin-left: 20px;
  width: auto;
  height: auto;
  margin-top: 10px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr 1fr;
}
.chart-wrapper {
  width: 600px;
  height: 300px;
  box-shadow: 0px 0px 5px rgb(0 0 0 / 16%);
  margin-bottom: 10px;
  margin-top: 10px;
  padding: 10px 10px;
  margin-right: 20px;

}
.words{
  display: absolute;
}
</style>
